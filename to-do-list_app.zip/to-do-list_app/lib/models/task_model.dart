class Task {
  String title;
  String description;
  String? emoji; // Emoji for priority/mood
  bool isCompleted;

  Task({
    required this.title,
    required this.description,
    this.emoji,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'description': description,
        'emoji': emoji,
        'isCompleted': isCompleted,
      };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
        title: json['title'],
        description: json['description'],
        emoji: json['emoji'],
        isCompleted: json['isCompleted'],
      );
}
