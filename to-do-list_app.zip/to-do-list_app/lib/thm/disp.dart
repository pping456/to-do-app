import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData lightTheme = ThemeData(
    fontFamily: 'Poppins',
    primarySwatch: Colors.pink,
    brightness: Brightness.light,
  );

  static ThemeData darkTheme = ThemeData(
    fontFamily: 'Poppins',
    primarySwatch: Colors.pink,
    brightness: Brightness.dark,
  );
}
