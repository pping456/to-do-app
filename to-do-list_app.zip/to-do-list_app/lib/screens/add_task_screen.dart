import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/task_model.dart';
import '../providers/task_provider.dart';

class AddTaskScreen extends StatefulWidget {
  final Task? task;
  final int? index;
  const AddTaskScreen({super.key, this.task, this.index});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  String title = '';
  String desc = '';
  String selectedEmoji = '🙂';

  final List<String> emojiOptions = ['😨', '🙂', '🎉', '💪', '⏰'];

  @override
  void initState() {
    super.initState();
    if (widget.task != null) {
      title = widget.task!.title;
      desc = widget.task!.description;
      selectedEmoji = widget.task!.emoji ?? '🙂';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.task == null ? 'Add Task ✏️' : 'Edit Task 📝')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                initialValue: title,
                decoration: const InputDecoration(labelText: 'Title'),
                validator: (v) => v == null || v.isEmpty ? 'Title required' : null,
                onSaved: (v) => title = v!,
              ),
              const SizedBox(height: 10),
              TextFormField(
                initialValue: desc,
                decoration: const InputDecoration(labelText: 'Description'),
                onSaved: (v) => desc = v ?? '',
              ),
              const SizedBox(height: 10),
              const Text('Select Emoji (Mood / Priority)'),
              DropdownButton<String>(
                value: selectedEmoji,
                items: emojiOptions.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (val) => setState(() => selectedEmoji = val!),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                child: Text(widget.task == null ? 'Save Task' : 'Update Task'),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    if (widget.task == null) {
                      Provider.of<TaskProvider>(context, listen: false).addTask(
                        Task(title: title, description: desc, emoji: selectedEmoji),
                      );
                    } else {
                      Provider.of<TaskProvider>(context, listen: false).updateTask(
                        widget.index!,
                        Task(title: title, description: desc, emoji: selectedEmoji),
                      );
                    }
                    Navigator.pop(context);
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
